
const CACHE_NAME = 'apd-v14.8-professional-god-mode';
const CORE_ASSETS = [
  './',
  './index.html',
  './index.tsx',
  './manifest.json',
  './logo.svg',
  './mandala.png'
];

// Force immediate activation for professional responsiveness
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('KERNEL_PRECACHE::INITIALIZING');
      return cache.addAll(CORE_ASSETS);
    })
  );
  self.skipWaiting();
});

// Clean up old kernel versions
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('KERNEL_PURGE::OLD_VERSION_DELETED', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Stale-While-Revalidate Fetch Strategy
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.match(event.request).then((response) => {
        const fetchPromise = fetch(event.request).then((networkResponse) => {
          // If network is available, update the cache for the next visit
          if (networkResponse.status === 200) {
            cache.put(event.request, networkResponse.clone());
          }
          return networkResponse;
        }).catch(() => {
          // Silent catch for offline status - use cached response
        });

        // Return the cached response immediately if it exists, otherwise wait for network
        return response || fetchPromise;
      });
    })
  );
});
