
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import AudioDeck from './components/AudioDeck';
import { AppState, AppTheme } from './types';
import { Music, ShieldCheck, ArrowRight, Zap } from 'lucide-react';
import { AudioProvider, useAudio } from './context/AudioContext';
import { CREATOR_NAME, APP_DISPLAY_NAME } from './constants';

const themeColors: Record<AppTheme, { accent: string; dim: string }> = {
  obsidian: { accent: '#FF6B00', dim: '#CC5500' },
  cobalt: { accent: '#00f0ff', dim: '#009bb3' },
  emerald: { accent: '#10b981', dim: '#059669' },
  amethyst: { accent: '#a855f7', dim: '#7e22ce' },
  crimson: { accent: '#ef4444', dim: '#b91c1c' }
};

const MandalaBackground = () => {
  const { isPlaying, nuclearMode, bgType, view } = useAudio();

  if (bgType === 'clean' || view !== 'player') return <div className="absolute inset-0 z-0 bg-tech-grid opacity-10 hardware-accelerated" />;

  return (
    <div className="absolute inset-0 z-0 pointer-events-none hardware-accelerated overflow-hidden">
      <motion.div 
        animate={{ 
          // Respiration speed: ~5 seconds per pulse cycle for maximum calm
          opacity: isPlaying ? [0.05, 0.12, 0.05] : 0.03,
          scale: isPlaying ? [1, 1.05, 1] : 1,
          filter: nuclearMode ? 'hue-rotate(320deg) saturate(1.5)' : 'hue-rotate(0deg)'
        }}
        transition={{ 
            duration: 10, 
            repeat: Infinity, 
            ease: [0.445, 0.05, 0.55, 0.95] // Sine easing
        }}
        className="absolute inset-0 will-change-transform"
        style={{
          backgroundImage: "url('./mandala.png')",
          backgroundRepeat: 'repeat',
          backgroundSize: '300px',
          mixBlendMode: 'plus-lighter',
          transform: 'translateZ(0)'
        }}
      />
      <div className="absolute inset-0 bg-tech-grid opacity-15 hardware-accelerated" />
    </div>
  );
};

function AppContent() {
  const [state, setState] = useState<AppState>(AppState.BOOTING);
  const { theme } = useAudio();

  useEffect(() => {
    const colors = themeColors[theme] || themeColors.obsidian;
    document.documentElement.style.setProperty('--theme-accent', colors.accent);
    document.documentElement.style.setProperty('--theme-accent-dim', colors.dim);
  }, [theme]);

  useEffect(() => {
    const hasVisited = localStorage.getItem("apd_onboarding_complete_v5");
    if (hasVisited) {
        setState(AppState.DASHBOARD);
    } else {
        const bootTimer = setTimeout(() => setState(AppState.PERMISSIONS), 2500); 
        return () => clearTimeout(bootTimer);
    }
  }, []);

  return (
    <div className="h-[100dvh] w-full bg-[#050505] text-white font-sans overflow-hidden relative flex flex-col selection:bg-mume-orange hardware-accelerated">
        <MandalaBackground />
        <AnimatePresence mode="wait">
          {state === AppState.BOOTING && (
            <motion.div 
              key="splash" exit={{ opacity: 0, scale: 1.05 }}
              className="absolute inset-0 z-[1000] bg-black flex flex-col items-center justify-center"
            >
              <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="flex flex-col items-center gap-6">
                  <div className="w-24 h-24 bg-mume-orange rounded-[2rem] flex items-center justify-center text-black shadow-[0_0_50px_rgba(255,107,0,0.3)]"><Zap size={48} fill="currentColor" /></div>
                  <div className="text-center"><h1 className="text-2xl font-tech font-bold tracking-[0.1em] text-white uppercase">{APP_DISPLAY_NAME}</h1><p className="text-[9px] font-mono text-mume-orange uppercase tracking-[0.4em] mt-1">SINGULARITY_OMEGA_ULTRA</p></div>
              </motion.div>
            </motion.div>
          )}
          {state === AppState.PERMISSIONS && (
            <motion.div key="on" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 z-[900] bg-[#050505] flex flex-col items-center justify-center p-8">
               <div className="w-full max-w-[280px] space-y-10 text-center flex flex-col items-center">
                   <div className="w-44 h-44 bg-white/5 rounded-full border border-white/10 flex items-center justify-center shadow-[0_0_40px_rgba(255,255,255,0.05)]"><ShieldCheck size={64} className="text-mume-orange" /></div>
                   <div className="space-y-3"><h2 className="text-2xl font-tech font-bold text-white uppercase tracking-wider">Kernel Secure</h2><p className="text-zinc-500 text-[11px] font-mono uppercase tracking-tight">Accessing the void to neutralize corporate audio trackers and DRM anchors.</p></div>
                   <button onClick={() => { localStorage.setItem("apd_onboarding_complete_v5", "true"); setState(AppState.DASHBOARD); }} className="w-full py-5 bg-mume-orange text-black font-tech font-bold rounded-2xl flex items-center justify-center gap-3 uppercase tracking-[0.2em] text-xs shadow-lg active:scale-95 transition-transform">Initialize Purge <ArrowRight size={18} /></button>
               </div>
            </motion.div>
          )}
          {state === AppState.DASHBOARD && (<motion.div key="dash" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 z-10 flex flex-col h-full overflow-hidden"><AudioDeck /></motion.div>)}
        </AnimatePresence>
    </div>
  );
}

function App() { return <AudioProvider><AppContent /></AudioProvider>; }
export default App;
