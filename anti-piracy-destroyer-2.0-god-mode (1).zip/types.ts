

export enum AppState {
  BOOTING = 'BOOTING',
  PERMISSIONS = 'PERMISSIONS',
  DASHBOARD = 'DASHBOARD',
  NUCLEAR_MODE = 'NUCLEAR_MODE'
}

export interface LoreEntry {
  title: string;
  content: string;
  hazardLevel: 'LOW' | 'MEDIUM' | 'CRITICAL' | 'NUCLEAR';
}

export interface AudioFile {
  name: string;
  // Fix: Made url optional as local tracks use File objects and temporary Blob URLs.
  url?: string;
  type: string;
  format?: string; 
  file?: File;
  dbId?: number;
  artist?: string;
  album?: string;
  cover?: string;
  purity?: number;
  morphicResonance?: number;
  entropy?: number;
}

export interface QueueItem {
  id: string;
  file: File;
  status: 'pending' | 'processing' | 'completed' | 'error';
}

export type PermissionStatus = 'idle' | 'requesting' | 'granted' | 'denied';

export enum AIProtocol {
  IDLE = 'IDLE',
  VOID_PURGE = 'VOID_PURGE',   
  MIDAS_TOUCH = 'MIDAS_TOUCH', 
  VITRUVIAN = 'VITRUVIAN',     
  COMMAND = 'COMMAND',         
  ANNIHILATOR_CORE = 'ANNIHILATOR_CORE',
  SIGNAL_DISRUPTION = 'SIGNAL_DISRUPTION',
  MORTAL_RECONSTRUCTION = 'MORTAL_RECONSTRUCTION',
  DRM_ERASER = 'DRM_ERASER'
}

export interface AIScannerState {
  online: boolean;
  analyzing: boolean;
  protocol: AIProtocol;
  confidence: number;
  threatLevel: number; 
  signature: string;   
  isHostile: boolean;  
  aiAnalysis?: string; 
}

export type RepeatMode = 'off' | 'all' | 'one';
export type ViewState = 'library' | 'player' | 'settings' | 'docs' | 'favorites' | 'architect' | 'nuclear';

export type AppTheme = 'obsidian' | 'cobalt' | 'emerald' | 'amethyst' | 'crimson';
export type BackgroundType = 'full' | 'grid' | 'clean';

export interface UploadStatus {
    current: number;
    total: number;
    filename: string;
    queueLength: number;
    entropyReduction?: number;
    purityGain?: number;
}

export interface ManifestReport {
    timestamp: number;
    durationMs: number;
    fileCount: number;
    totalSize: number;
    protocolsApplied: string[];
    integrityHash: string;
}

export interface ProtocolState {
  neuro: boolean;
  annihilator: boolean;
  gateway: boolean;
  morphic: boolean; 
  comb: boolean; 
  nuclear: boolean;
}