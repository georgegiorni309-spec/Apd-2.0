
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import ErrorBoundary from './components/ErrorBoundary';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

// Advanced Service Worker Registration for Professional Android Deployment
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then(registration => {
        console.log('KERNEL::DEPLOYED - SW Status:', registration.active ? 'ACTIVE' : 'INITIALIZING');
        
        // Handle background kernel updates
        registration.onupdatefound = () => {
          const installingWorker = registration.installing;
          if (installingWorker) {
            installingWorker.onstatechange = () => {
              if (installingWorker.state === 'installed') {
                if (navigator.serviceWorker.controller) {
                  console.log('KERNEL::NEW_DEPLOYMENT_READY - RELOAD TO APPLY');
                  window.dispatchEvent(new CustomEvent('apd-system-log', { detail: 'NEW_KERNEL_DEPLOYMENT_READY::REBOOT_REQUIRED' }));
                }
              }
            };
          }
        };
      })
      .catch(err => {
        console.warn('KERNEL::DEPLOYMENT_FAILED:', err);
      });
  });
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);
