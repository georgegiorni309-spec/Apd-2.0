
import React, { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="h-screen w-full bg-[#050505] text-red-500 flex flex-col items-center justify-center p-8 font-mono relative overflow-hidden">
          <div className="absolute inset-0 bg-noise opacity-20"></div>
          
          <div className="border-2 border-red-600/50 bg-black/95 p-8 max-w-lg w-full relative z-10 text-center shadow-[0_0_80px_rgba(239,68,68,0.3)] rounded-[2.5rem]">
            <AlertTriangle size={64} className="mx-auto mb-6 text-red-600 animate-pulse" />
            <h1 className="text-2xl font-tech font-bold tracking-[0.2em] mb-4 text-white uppercase">SYSTEM FAILURE</h1>
            
            <div className="bg-red-950/20 p-6 border border-red-900/30 rounded-2xl mb-8 text-center">
              <p className="text-sm text-zinc-300 font-bold uppercase tracking-tight">
                There was an unexpected error. Finish what you were doing.
              </p>
              <div className="h-px w-full bg-red-900/20 my-4"></div>
              <p className="text-[10px] text-red-400/60 break-all font-mono italic">
                {this.state.error?.message || "KERNEL_FAULT::ANNIHILATION_INTERRUPTED"}
              </p>
            </div>

            <button 
              onClick={() => window.location.reload()}
              className="px-8 py-4 bg-red-600 text-white font-tech font-bold tracking-widest text-sm flex items-center justify-center gap-3 mx-auto transition-all active:scale-95 shadow-[0_10px_30px_rgba(239,68,68,0.4)] rounded-xl"
            >
              <RefreshCw size={18} />
              REBOOT_ANNIHILATOR
            </button>
            
            <p className="mt-8 text-[7px] text-zinc-700 font-mono uppercase tracking-[0.4em] font-bold">
               ARCHITECT::JHONDURD3N // RECOVERY_KERNEL_STABLE
            </p>
          </div>
        </div>
      );
    }

    return (this as any).props.children;
  }
}

export default ErrorBoundary;
