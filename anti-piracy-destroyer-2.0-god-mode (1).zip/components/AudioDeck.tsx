
import React, { useRef, useEffect, useState, memo } from 'react';
import { 
  Play, Pause, Upload, SkipBack, SkipForward, X, Activity, Flame, Disc, Database, BookOpen, Settings as SettingsIcon,
  Power, Palette, Zap, RefreshCw, Terminal as TerminalIcon, Repeat, Repeat1, Shuffle, ArrowRight, User, Cpu, BarChart2,
  Loader2, Download, Layers, MessageSquare, Trash2, Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import TerminalOutput from './TerminalOutput';
import OperationsManual from './OperationsManual';
import DonationPanel from './DonationPanel';
import UpgradeModal from './UpgradeModal';
import Powerboost from './Powerboost'; 
import { useAudio } from '../context/AudioContext';
import { APP_DISPLAY_NAME, CREATOR_NAME, UPDATE_URL } from '../constants';
import { Howler } from 'howler';
import { AudioFile } from '../types';

const formatTime = (seconds: number) => {
    if (!Number.isFinite(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
};

const TrackItem = memo(({ track, isActive, isPlaying, onPlay, onExport }: { track: AudioFile, isActive: boolean, isPlaying: boolean, onPlay: () => void, onExport: () => void }) => (
  <motion.div 
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} 
      onClick={onPlay} 
      className={`relative group p-4 rounded-2xl flex items-center justify-between border transition-all duration-300 active:scale-[0.97] cursor-pointer overflow-hidden ${isActive ? 'bg-mume-orange/10 border-mume-orange/50 shadow-[0_0_25px_rgba(255,107,0,0.1)]' : 'bg-white/[0.03] border-white/[0.05] hover:border-white/20'}`}
  >
      {isActive && <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-mume-orange shadow-[0_0_15px_var(--theme-accent)]" />}
      <div className="flex items-center gap-4 min-w-0">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-all ${isActive ? 'bg-mume-orange border-mume-orange text-black shadow-[0_0_15px_rgba(255,107,0,0.4)]' : 'bg-black border-white/10 text-zinc-400'}`}>
              <Disc size={18} className={isActive && isPlaying ? 'animate-spin-slow' : ''} />
          </div>
          <div className="flex flex-col min-w-0">
              <span className={`text-[12px] font-tech font-bold uppercase truncate tracking-wider leading-tight text-glow-premium ${isActive ? 'text-white' : 'text-zinc-200 group-hover:text-white'}`}>{track.name}</span>
              <div className="flex items-center gap-2 mt-1.5">
                <span className={`text-[9px] font-mono uppercase tracking-[0.2em] font-bold ${isActive ? 'text-mume-orange' : 'text-zinc-500'}`}>SIGNAL: {isActive ? 'SYNCED' : 'ENCRYPTED'}</span>
                {isActive && <div className="w-1.5 h-1.5 rounded-full bg-mume-orange animate-pulse" />}
              </div>
          </div>
      </div>
      <div className="flex items-center gap-3">
        {isActive && (
          <button 
            onClick={(e) => { e.stopPropagation(); onExport(); }} 
            className="p-2.5 bg-red-600/10 rounded-lg text-red-500/60 border border-red-600/20 transition-all active:scale-90 hover:bg-red-600/20 hover:text-red-500"
            title="Protocol Locked"
          >
            <Lock size={14} />
          </button>
        )}
        {isActive && isPlaying && <Activity size={14} className="text-mume-orange animate-pulse mr-1" />}
      </div>
  </motion.div>
));

const NavBtn = ({ active, onClick, icon: Icon, label }: { active: boolean, onClick: () => void, icon: any, label: string }) => (
  <motion.button 
    whileTap={{ scale: 0.92 }}
    onClick={onClick} 
    className={`relative flex-1 flex flex-col items-center justify-center gap-2 py-3 rounded-2xl transition-all duration-500 ${active ? 'text-mume-orange' : 'text-zinc-500 hover:text-zinc-300'}`}
  >
    {active && <motion.div layoutId="nav-bg" className="absolute inset-0 bg-white/[0.05] rounded-2xl -z-10" />}
    <Icon size={18} strokeWidth={active ? 2.5 : 2} className={`will-change-transform ${active ? 'filter drop-shadow-[0_0_5px_var(--theme-accent)]' : ''}`} />
    <span className={`text-[9px] font-tech font-bold uppercase tracking-[0.2em] transition-all ${active ? 'opacity-100 scale-105 text-glow' : 'opacity-40 scale-100'}`}>
      {label}
    </span>
  </motion.button>
);

const AudioDeck: React.FC = () => {
  const {
    view, setView, playlist, isPlaying, currentTime, duration, nuclearMode, toggleNuclearMode, showTerminal, setShowTerminal, showDonation, setShowDonation,
    showUpgradeModal, setShowUpgradeModal, togglePlay, playTrack, nextTrack, prevTrack, seek, processFiles, currentTrack, analyser, clearPlaylist, theme, setTheme,
    isShuffle, toggleShuffle, repeatMode, toggleRepeat, perfTier, isVisible, isProcessing, processingProgress, exportTrack, exportStatus, isOnline, bgType, setBgType, toasts, removeToast
  } = useAudio();

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dataBufferRef = useRef<Uint8Array | null>(null); 
  const rotRef = useRef(0);

  useEffect(() => {
    if (!analyser) return;
    analyser.smoothingTimeConstant = 0.9; 
    dataBufferRef.current = new Uint8Array(analyser.frequencyBinCount);
    
    let lastTime = 0;
    const loop = (time: number) => {
      if (!isVisible || document.hidden) { rafRef.current = requestAnimationFrame(loop); return; }
      const targetDelta = 33; 
      if (time - lastTime < targetDelta) { rafRef.current = requestAnimationFrame(loop); return; }
      lastTime = time;

      if (canvasRef.current && isPlaying && dataBufferRef.current) {
        const ctx = canvasRef.current.getContext('2d', { alpha: false });
        if (ctx) {
          ctx.fillStyle = '#020202'; ctx.fillRect(0, 0, 400, 400);
          analyser.getByteFrequencyData(dataBufferRef.current);
          rotRef.current += nuclearMode ? 0.015 : 0.006;
          ctx.save(); ctx.translate(200, 200); ctx.rotate(rotRef.current);
          ctx.strokeStyle = 'var(--theme-accent)'; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
          ctx.beginPath();
          const bins = 24; 
          for (let i = 0; i < bins; i++) {
            const val = dataBufferRef.current[i * 2] || 0;
            const r = 80 + (val / 200 * (nuclearMode ? 60 : 30));
            const angle = (i / bins) * Math.PI * 2;
            const x = Math.cos(angle) * r, y = Math.sin(angle) * r;
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          }
          ctx.closePath(); ctx.stroke(); 
          ctx.globalAlpha = 0.12; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, 100, 0, Math.PI * 2); ctx.stroke();
          ctx.restore();
        }
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [isPlaying, nuclearMode, analyser, isVisible]);

  return (
    <div className="fixed inset-0 bg-[#020202] flex flex-col h-[100dvh] overflow-hidden select-none text-white font-sans hardware-accelerated">
      {/* Toast Layer */}
      <div className="fixed top-[max(1.5rem,env(safe-area-inset-top))] left-1/2 -translate-x-1/2 z-[3000] w-full max-w-[320px] px-6 pointer-events-none">
        <AnimatePresence>
          {toasts.map(toast => (
            <motion.div 
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={`mb-3 p-4 rounded-2xl border backdrop-blur-xl shadow-2xl flex items-center gap-3 pointer-events-auto ${toast.type === 'error' ? 'bg-red-900/60 border-red-500/40 text-red-100' : 'bg-black/80 border-mume-orange/40 text-white'}`}
            >
              {toast.type === 'error' ? <Lock size={16} className="shrink-0" /> : <Activity size={16} className="shrink-0" />}
              <span className="text-[10px] font-tech font-bold uppercase tracking-widest text-glow-premium">{toast.message}</span>
              <button onClick={() => removeToast(toast.id)} className="ml-auto p-1.5 opacity-40 hover:opacity-100"><X size={14} /></button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <header className="pt-[max(1.2rem,env(safe-area-inset-top))] px-6 pb-5 shrink-0 z-40 glass-panel border-b border-white/[0.05] flex items-center justify-between">
          <div className="flex flex-col">
              <div className="flex items-center gap-2 mb-1.5">
                 <span className="text-[9px] font-mono text-mume-orange uppercase tracking-[0.4em] font-bold opacity-60 leading-none">KERNEL_SIGNAL_OS_14.8.1</span>
                 <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${isOnline ? 'bg-mume-orange/60 shadow-[0_0_5px_var(--theme-accent)]' : 'bg-zinc-800'}`} />
              </div>
              <h1 className="text-[12px] font-tech font-bold text-white uppercase tracking-[0.2em] flex items-center gap-2.5 text-shadow-tech">
                <div className={`w-2 h-2 rounded-full status-led ${isOnline ? 'bg-mume-orange' : 'bg-zinc-600'}`} />
                {APP_DISPLAY_NAME}
              </h1>
          </div>
          <div className="flex gap-3 items-center">
              <motion.button 
                whileTap={{ scale: 0.9 }} 
                onClick={() => fileInputRef.current?.click()} 
                className={`p-2.5 bg-white/[0.05] text-zinc-300 rounded-xl border border-white/[0.1] hover:text-white hover:bg-white/[0.1] transition-all ${isProcessing ? 'animate-pulse' : ''}`}
                disabled={isProcessing}
              >
                {isProcessing ? <Loader2 size={16} className="animate-spin text-mume-orange" /> : <Upload size={16} />}
              </motion.button>
              <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowTerminal(!showTerminal)} className={`p-2.5 rounded-xl border transition-all ${showTerminal ? 'bg-mume-orange text-black border-mume-orange shadow-[0_0_20px_rgba(255,107,0,0.3)]' : 'bg-white/[0.05] border-white/[0.1] text-zinc-400'}`}><TerminalIcon size={16} /></motion.button>
          </div>
      </header>

      <main className="flex-1 relative flex flex-col overflow-hidden bg-tech-grid bg-[size:40px_40px]">
        <AnimatePresence mode="wait">
          {view === 'library' && (
            <motion.div key="lib" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 flex flex-col pt-8">
                <div className="flex items-center justify-between px-6 mb-8">
                    <div className="flex flex-col">
                      <span className="text-[11px] font-tech font-bold text-mume-orange uppercase tracking-[0.3em] text-glow">Signal Archive</span>
                      <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest leading-none mt-2 font-bold">TOTAL_NODES: {playlist.length}</span>
                    </div>
                    {playlist.length > 0 && (
                      <button onClick={() => { if(confirm("VOID_ALL_CACHE?")) clearPlaylist(); }} className="px-5 py-2.5 bg-red-600/10 border border-red-600/30 rounded-xl text-[10px] font-tech font-bold text-red-500 uppercase tracking-widest hover:bg-red-600/20 transition-all active:scale-95 shadow-lg shadow-red-900/10">Void Cache</button>
                    )}
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar px-6 pb-28 space-y-3 overscroll-contain">
                    {playlist.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center opacity-20 gap-6">
                            <Database size={48} strokeWidth={1} />
                            <p className="text-[12px] font-tech uppercase tracking-[0.6em] font-bold">No Data Detected</p>
                        </div>
                    ) : (
                      playlist.map((track) => (
                        <TrackItem key={track.dbId} track={track} isActive={currentTrack?.dbId === track.dbId} isPlaying={isPlaying} onPlay={() => playTrack(track)} onExport={() => exportTrack(track)} />
                      ))
                    )}
                </div>
            </motion.div>
          )}

          {view === 'player' && (
            <motion.div key="player" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="h-full flex flex-col items-center justify-center px-8 pb-24 pt-4 relative">
                <div className="relative w-full aspect-square max-w-[280px] flex items-center justify-center mb-12">
                    <canvas ref={canvasRef} width={400} height={400} className="absolute inset-0 w-full h-full opacity-25 pointer-events-none" />
                    <div className={`w-44 h-44 sm:w-56 sm:h-56 rounded-full border transition-all duration-1000 ${nuclearMode ? 'border-red-600 shadow-[0_0_60px_rgba(239,68,68,0.2)]' : 'border-white/[0.08]'}`}>
                        <div className="w-[calc(100%-14px)] h-[calc(100%-14px)] rounded-full bg-black/70 backdrop-blur-3xl border border-white/[0.05] flex items-center justify-center relative overflow-hidden shadow-2xl">
                          <Powerboost />
                          <Disc size={36} className={`text-white opacity-10 ${isPlaying ? 'animate-spin-slow' : ''}`} />
                        </div>
                    </div>
                    <motion.button whileTap={{ scale: 0.8 }} onClick={toggleNuclearMode} className={`absolute -top-3 -right-3 w-12 h-12 rounded-2xl border flex items-center justify-center transition-all shadow-2xl z-20 ${nuclearMode ? 'bg-red-600 border-red-400 text-white shadow-[0_0_30px_rgba(239,68,68,0.5)]' : 'bg-mume-card border-white/10 text-zinc-500 hover:text-white hover:border-mume-orange/50'}`}>
                      <Flame size={22} fill={nuclearMode ? "currentColor" : "none"} />
                    </motion.button>
                </div>
                <div className="w-full space-y-10 text-center max-w-sm">
                    <div className="px-4">
                      <div className="flex items-center justify-center gap-4 mb-3 opacity-60">
                        <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-mume-orange" />
                        <span className="text-[9px] font-mono text-mume-orange uppercase tracking-[0.6em] font-bold text-glow">CORE_LINK</span>
                        <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-mume-orange" />
                      </div>
                      <h2 className="text-[16px] font-tech font-bold text-white uppercase tracking-[0.3em] truncate mb-3 leading-none text-glow text-glow-premium">{currentTrack?.name || 'WAITING_FOR_SIGNAL'}</h2>
                      <div className="flex items-center justify-center gap-2.5">
                        <span className={`text-[10px] font-mono uppercase tracking-[0.4em] font-bold transition-all ${isPlaying ? 'text-green-500 text-glow' : 'text-zinc-600'}`}>{isPlaying ? 'SIGNAL_ESTABLISHED' : 'CARRIER_WAIT'}</span>
                        {isPlaying && <Activity size={10} className="text-green-500 animate-pulse" />}
                      </div>
                    </div>
                    
                    <div className="w-full space-y-4 px-2">
                        <div className="flex justify-between text-[11px] font-mono text-zinc-300 font-bold uppercase tracking-[0.2em] px-1">
                          <span className="text-mume-orange text-glow-premium">{formatTime(currentTime)}</span>
                          <span>{formatTime(duration)}</span>
                        </div>
                        <div className="relative group px-1">
                          <input type="range" min={0} max={duration || 100} step={0.1} value={currentTime} onChange={(e) => seek(parseFloat(e.target.value))} className="w-full h-2 bg-white/[0.08] rounded-full appearance-none accent-mume-orange cursor-pointer shadow-inner relative z-10" />
                          <div className="absolute top-0 bottom-0 left-0 bg-mume-orange/40 blur-xl -z-10 rounded-full transition-all" style={{ width: `${(currentTime / duration) * 100}%` }} />
                        </div>
                    </div>

                    <div className="flex items-center justify-between px-2 pt-6">
                        <motion.button whileTap={{ scale: 0.85 }} onClick={toggleShuffle} className={`p-4 rounded-2xl border transition-all ${isShuffle ? 'bg-mume-orange/20 border-mume-orange/50 text-mume-orange shadow-[0_0_20px_rgba(255,107,0,0.3)]' : 'bg-white/[0.05] border-white/[0.1] text-zinc-400 hover:text-white'}`}><Shuffle size={18} /></motion.button>
                        <div className="flex items-center gap-6">
                          <motion.button whileTap={{ scale: 0.85 }} onClick={prevTrack} className="p-2 text-zinc-300 hover:text-white transition-colors"><SkipBack size={26} fill="currentColor" /></motion.button>
                          <motion.button whileTap={{ scale: 0.9 }} onClick={togglePlay} className={`w-20 h-20 rounded-3xl flex items-center justify-center border transition-all shadow-[0_20px_60px_rgba(0,0,0,0.8)] ${nuclearMode ? 'bg-red-700 border-red-500 text-white shadow-red-900/40' : 'bg-white border-white text-black active:bg-zinc-200'}`}>
                            {isPlaying ? <Pause size={36} fill="currentColor" /> : <Play size={36} className="ml-1" fill="currentColor" />}
                          </motion.button>
                          <motion.button whileTap={{ scale: 0.85 }} onClick={nextTrack} className="p-2 text-zinc-300 hover:text-white transition-colors"><SkipForward size={26} fill="currentColor" /></motion.button>
                        </div>
                        <motion.button whileTap={{ scale: 0.85 }} onClick={toggleRepeat} className={`p-4 rounded-2xl border transition-all ${repeatMode !== 'off' ? 'bg-mume-orange/20 border-mume-orange/50 text-mume-orange shadow-[0_0_20px_rgba(255,107,0,0.3)]' : 'bg-white/[0.05] border-white/[0.1] text-zinc-400 hover:text-white'}`}>
                          {repeatMode === 'one' ? <Repeat1 size={18} /> : <Repeat size={18} />}
                        </motion.button>
                    </div>
                </div>
            </motion.div>
          )}

          {view === 'settings' && (
            <motion.div key="settings" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full px-6 py-10 overflow-y-auto custom-scrollbar overscroll-contain pb-32">
                <div className="space-y-8 max-w-md mx-auto">
                    {/* Architect Ident */}
                    <div className="p-8 glass-card rounded-[2.5rem] flex items-center gap-8 shadow-xl">
                      <div className="w-16 h-16 bg-black rounded-2xl flex items-center justify-center border border-mume-orange/40 shadow-inner text-mume-orange"><User size={32} /></div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-tech font-bold text-zinc-500 uppercase tracking-[0.5em] mb-2 leading-none">Architect Ident</span>
                        <span className="text-xl font-tech font-bold text-white uppercase tracking-[0.1em] text-glow-premium">{CREATOR_NAME}</span>
                      </div>
                    </div>

                    {/* Kernel Status */}
                    <div className="p-8 glass-card rounded-[2.5rem] space-y-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[12px] font-tech font-bold text-zinc-200 uppercase tracking-[0.2em] flex items-center gap-3"><RefreshCw size={18} className="text-mume-orange" /> Kernel Status</span>
                        <span className="text-[10px] font-mono text-green-500 font-bold px-4 py-2 bg-green-500/10 rounded-full border border-green-500/20 shadow-lg shadow-green-900/20">LINK_STABLE</span>
                      </div>
                      <a href={UPDATE_URL} target="_blank" rel="noopener noreferrer" className="w-full p-6 bg-white/[0.03] border border-white/[0.1] rounded-2xl flex items-center justify-between hover:bg-mume-orange/10 hover:border-mume-orange/40 transition-all group active:scale-[0.98]">
                        <div className="flex flex-col"><span className="text-[13px] font-tech font-bold text-white uppercase tracking-widest group-hover:text-mume-orange transition-colors">Kernel Repository</span><span className="text-[10px] font-mono text-zinc-500 uppercase mt-2 group-hover:text-zinc-300">Direct Updates Path</span></div>
                        <ArrowRight size={20} className="text-zinc-700 group-hover:translate-x-1.5 transition-all group-hover:text-mume-orange" />
                      </a>
                    </div>

                    {/* Master Output Control */}
                    <div className="p-8 glass-card rounded-[2.5rem] space-y-5">
                        <span className="text-[12px] font-tech font-bold text-zinc-200 uppercase tracking-widest flex items-center gap-3"><Power size={20} className="text-mume-orange" /> Master Output</span>
                        <input 
                          type="range" 
                          min={0} max={100} 
                          defaultValue={Howler.volume() * 100} 
                          onChange={(e) => Howler.volume(parseInt(e.target.value) / 100)} 
                          className="w-full h-2 bg-black/60 rounded-full appearance-none accent-mume-orange cursor-pointer border border-white/5 shadow-inner" 
                        />
                    </div>
                </div>
            </motion.div>
          )}

          {view === 'docs' && (<motion.div key="docs" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full px-6 py-6 overflow-y-auto custom-scrollbar pb-32 overscroll-contain"><OperationsManual /></motion.div>)}
        </AnimatePresence>

        <AnimatePresence>{showTerminal && (<motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }} className="absolute inset-0 z-[100] bg-black/98 backdrop-blur-3xl overflow-hidden flex flex-col"><div className="p-6 border-b border-white/[0.08] flex items-center justify-between shrink-0"><h3 className="text-[12px] font-tech font-bold text-mume-orange uppercase tracking-[0.6em] text-glow">System Protocol Log</h3><button onClick={() => setShowTerminal(false)} className="p-2.5 text-zinc-400 hover:text-white transition-colors"><X size={26} /></button></div><div className="flex-1 overflow-hidden p-4"><TerminalOutput /></div></motion.div>)}</AnimatePresence>
      </main>

      <footer className="shrink-0 z-50 px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-3 glass-panel border-t border-white/[0.08] shadow-[0_-25px_60px_rgba(0,0,0,0.9)]">
        <nav className="flex items-center justify-between gap-2 max-w-md mx-auto h-20">
          <NavBtn active={view === 'library'} onClick={() => setView('library')} icon={Database} label="Vault" />
          <NavBtn active={view === 'player'} onClick={() => setView('player')} icon={Zap} label="Core" />
          <div className="w-[2px] h-10 bg-white/[0.1] mx-4 flex self-center" />
          <NavBtn active={view === 'docs'} onClick={() => setView('docs')} icon={BookOpen} label="Intel" />
          <NavBtn active={view === 'settings'} onClick={() => setView('settings')} icon={SettingsIcon} label="Kernel" />
        </nav>
      </footer>

      <input type="file" ref={fileInputRef} className="hidden" multiple accept="audio/*" onChange={(e) => { if (e.target.files) processFiles(Array.from(e.target.files)); }} />
      <UpgradeModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} />
      <DonationPanel isOpen={showDonation} onClose={() => setShowDonation(false)} />
    </div>
  );
};

export default AudioDeck;
