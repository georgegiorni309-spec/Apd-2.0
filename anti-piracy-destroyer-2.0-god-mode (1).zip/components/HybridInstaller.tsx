import React, { useState, useEffect } from 'react';
import { Smartphone, Download, CheckCircle, Cpu } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const HybridInstaller: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Check if already running in standalone (APK) mode
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                         (window.navigator as any).standalone;
    
    if (isStandalone) {
      setIsInstalled(true);
    }

    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handler);

    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  if (!deferredPrompt && !isInstalled) return null;

  return (
    <div className="flex items-center">
      <AnimatePresence>
        {isInstalled ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center gap-1.5 px-2 py-1 bg-zinc-900/50 border border-zinc-800 rounded-sm"
          >
            <Cpu size={10} className="text-terminal-green" />
            <span className="text-[9px] font-mono text-zinc-500 tracking-wider">HYBRID::NATIVE</span>
          </motion.div>
        ) : (
          <motion.button
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, width: 0 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleInstall}
            className="group relative flex items-center gap-2 px-3 py-1 bg-alchemy-gold text-black font-header font-bold text-[9px] tracking-widest uppercase border border-alchemy-gold hover:bg-white hover:text-black transition-all shadow-[0_0_10px_rgba(212,175,55,0.3)]"
          >
            <Download size={10} className="animate-bounce" />
            <span>Deploy App</span>
            <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500"></div>
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
};

export default HybridInstaller;