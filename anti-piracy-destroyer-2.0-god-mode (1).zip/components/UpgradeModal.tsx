
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Zap, Radio, Cpu, X, Terminal, Flame, Check, ShieldAlert, Target, Atom } from 'lucide-react';
import { CREATOR_NAME, APP_VERSION } from '../constants';

interface UpgradeModalProps {
  onClose: () => void;
  isOpen: boolean;
}

const UpgradeModal: React.FC<UpgradeModalProps> = ({ onClose, isOpen }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[1200] flex items-center justify-center bg-black/95 backdrop-blur-xl p-6 hardware-accelerated"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 20, opacity: 0 }}
            transition={{ type: "spring", stiffness: 350, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-[#050505] border border-mume-orange/40 rounded-[2.5rem] relative overflow-hidden shadow-[0_0_80px_rgba(255,107,0,0.2)]"
          >
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,107,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,107,0,0.03)_1px,transparent_1px)] bg-[size:30px_30px] pointer-events-none opacity-50"></div>

            <div className="relative z-10 p-8">
                <button 
                    onClick={onClose}
                    className="absolute top-6 right-6 text-zinc-600 hover:text-white transition-colors p-2"
                >
                    <X size={24} />
                </button>

                <div className="flex flex-col items-center text-center mb-8">
                    <div className="w-20 h-20 bg-mume-orange/10 rounded-full flex items-center justify-center mb-4 border border-mume-orange/30 shadow-[0_0_30px_rgba(255,107,0,0.1)]">
                        <Target size={40} className="text-mume-orange animate-pulse" />
                    </div>
                    <h2 className="text-2xl font-tech font-bold text-white uppercase tracking-[0.2em] mb-1">
                        Annihilator Pro
                    </h2>
                    <p className="text-[10px] font-mono text-mume-orange uppercase tracking-[0.3em] font-bold">
                        Architect: {CREATOR_NAME} // GOD_MODE
                    </p>
                </div>

                <div className="space-y-3 mb-8">
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                        <div className="flex items-center gap-4">
                            <div className="p-2 bg-red-600/20 rounded-xl text-red-500"><ShieldAlert size={18} /></div>
                            <span className="text-xs font-tech font-bold uppercase tracking-widest text-zinc-300">Paid Signal Eraser</span>
                        </div>
                        <span className="text-[9px] font-mono text-red-500 font-bold uppercase tracking-widest">ENABLED</span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                        <div className="flex items-center gap-4">
                            <div className="p-2 bg-tech-cyan/20 rounded-xl text-tech-cyan"><Zap size={18} /></div>
                            <span className="text-xs font-tech font-bold uppercase tracking-widest text-zinc-300">Subliminal Decoupler</span>
                        </div>
                        <span className="text-[9px] font-mono text-tech-cyan font-bold uppercase tracking-widest">ACTIVE</span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                        <div className="flex items-center gap-4">
                            <div className="p-2 bg-purple-500/20 rounded-xl text-purple-400"><Atom size={18} /></div>
                            <span className="text-xs font-tech font-bold uppercase tracking-widest text-zinc-300">Morphic Rebuilder</span>
                        </div>
                        <span className="text-[9px] font-mono text-purple-400 font-bold uppercase tracking-widest">ULTRA</span>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                        <div className="flex items-center gap-4">
                            <div className="p-2 bg-yellow-500/20 rounded-xl text-yellow-500"><Flame size={18} /></div>
                            <span className="text-xs font-tech font-bold uppercase tracking-widest text-zinc-300">Nuclear Overdrive</span>
                        </div>
                        <span className="text-[9px] font-mono text-yellow-500 font-bold uppercase tracking-widest">UNLOCKED</span>
                    </div>
                </div>

                <button 
                    onClick={onClose}
                    className="w-full py-4 bg-mume-orange text-black font-tech font-bold uppercase tracking-[0.2em] rounded-2xl shadow-[0_10px_40px_rgba(255,107,0,0.3)] active:scale-95 transition-all flex items-center justify-center gap-3 group"
                >
                    <Terminal size={18} className="group-hover:rotate-12 transition-transform" />
                    Enter the Core
                </button>
                
                <p className="mt-6 text-[8px] text-zinc-600 text-center font-mono uppercase tracking-[0.3em] font-bold">
                    PROPER ANNIHILATION OF ALL PAID SIGNATURES & DRM ENABLED
                </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default UpgradeModal;
