
import React from 'react';
import { X, Copy, ShoppingCart, Mail, MessageSquare, Terminal, Copyright } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { CONTACT_EMAIL, STORE_URL, CREATOR_NAME, APP_VERSION } from '../constants';

interface DonationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const DonationPanel: React.FC<DonationPanelProps> = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[2000] flex items-center justify-center bg-black/85 backdrop-blur-sm p-6"
          onClick={onClose}
        >
          <motion.div 
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="w-full max-w-sm bg-[#0f0f0f] rounded-[2.5rem] border border-white/10 shadow-[0_0_80px_rgba(0,0,0,0.8)] overflow-hidden relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="absolute inset-0 bg-tech-grid opacity-20 pointer-events-none"></div>
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-mume-orange/40 to-transparent"></div>

            <div className="p-8 relative z-10">
                <div className="flex justify-between items-start mb-8">
                    <div className="w-16 h-16 bg-mume-orange/10 rounded-2xl flex items-center justify-center border border-mume-orange/20 shadow-inner">
                        <MessageSquare size={32} className="text-mume-orange" />
                    </div>
                    <button 
                        onClick={onClose} 
                        className="w-10 h-10 flex items-center justify-center bg-white/5 rounded-full text-zinc-500 hover:text-white hover:bg-white/10 transition-all border border-transparent hover:border-white/10"
                    >
                        <X size={20} />
                    </button>
                </div>

                <h2 className="text-3xl font-tech font-bold text-white mb-6 uppercase tracking-[0.1em]">Contact Us</h2>
                
                <div className="bg-[#141414] border border-mume-orange/10 rounded-2xl p-5 mb-6 shadow-inner">
                    <p className="text-[11px] text-zinc-400 font-tech uppercase tracking-widest mb-3">
                        SYSTEM STATUS: <span className="text-mume-orange font-bold">ACTIVE</span>.
                    </p>
                    <p className="text-[10px] text-zinc-500 font-sans leading-relaxed">
                        Authorized channel for reporting signal instabilities, requesting core features, or sharing direct feedback with the architect.
                    </p>
                </div>

                <div className="space-y-2 mb-8">
                    <span className="text-[10px] text-zinc-600 font-bold font-mono uppercase tracking-widest ml-1">Email Identifier</span>
                    <div 
                        onClick={() => {
                            try {
                                navigator.clipboard.writeText(CONTACT_EMAIL);
                            } catch (e) {}
                        }}
                        className="group bg-black border border-white/5 rounded-2xl p-4 flex items-center justify-between cursor-pointer hover:border-mume-orange/30 transition-all active:scale-[0.98]"
                    >
                        <span className="text-sm font-mono text-zinc-300 tracking-tight lowercase">{CONTACT_EMAIL}</span>
                        <Copy size={18} className="text-zinc-700 group-hover:text-mume-orange transition-colors" />
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-10">
                    <a 
                        href={`mailto:${CONTACT_EMAIL}`} 
                        className="py-4 bg-white text-black font-tech font-bold uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 text-[11px] hover:bg-zinc-200 transition-colors shadow-lg active:scale-95"
                    >
                        <Mail size={16} /> Send Email
                    </a>
                    <a 
                        href={STORE_URL} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="py-4 bg-black text-white font-tech font-bold uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 text-[11px] border border-white/10 hover:border-mume-orange hover:text-mume-orange transition-all active:scale-95"
                    >
                        <ShoppingCart size={16} /> Online Store
                    </a>
                </div>

                <div className="space-y-4 text-center">
                    <div className="flex items-center justify-between px-2">
                        <span className="text-[10px] font-bold text-zinc-700 font-mono uppercase tracking-widest">VERSION</span>
                        <span className="text-[10px] font-mono text-mume-orange/60 font-bold">{APP_VERSION}</span>
                    </div>
                    <div className="flex items-center justify-center gap-3 pt-4 border-t border-white/5">
                       <Terminal size={14} className="text-zinc-700" />
                       <span className="text-[10px] text-zinc-600 font-mono uppercase tracking-[0.3em]">Developer: <span className="text-zinc-400">{CREATOR_NAME}</span></span>
                    </div>
                </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DonationPanel;
