
import React, { useState } from 'react';
import { 
  ChevronDown, Shield, Activity, Target, Cpu, Info, Zap, Trash2, ShieldCheck, Lock, ShieldAlert, Atom
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
// Added APP_DISPLAY_NAME to the import list from constants
import { CREATOR_NAME, APP_VERSION, DETAILED_BENEFITS, APP_DISPLAY_NAME } from '../constants';

interface AccordionItemProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const AccordionItem: React.FC<AccordionItemProps> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className={`rounded-3xl border transition-all duration-500 overflow-hidden mb-6 ${isOpen ? 'bg-white/[0.08] border-mume-orange/60 shadow-[0_0_60px_rgba(255,107,0,0.2)]' : 'bg-zinc-900/60 border-white/10 hover:border-mume-orange/30'}`}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-8 flex items-center justify-between active:scale-[0.99] transition-transform"
      >
        <h3 className={`text-[15px] font-bold text-left font-tech tracking-[0.2em] uppercase transition-colors ${isOpen ? 'text-mume-orange text-glow' : 'text-zinc-100'}`}>{title}</h3>
        <ChevronDown size={20} className={`text-zinc-500 transition-all duration-500 ${isOpen ? 'rotate-180 text-mume-orange scale-110' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.5, ease: "circOut" }}
          >
            <div className="px-8 pb-10 pt-0">
               <div className="h-px w-full bg-gradient-to-r from-transparent via-mume-orange/40 to-transparent mb-8"></div>
               <div className="space-y-6">
                {children}
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const OperationsManual: React.FC = () => {
  return (
    <div className="flex flex-col gap-10 w-full max-w-2xl mx-auto pb-24 px-2">
       
       <div className="relative p-10 rounded-[3.5rem] bg-zinc-900/95 border border-mume-orange/40 overflow-hidden shadow-2xl">
          <div className="absolute -top-10 -right-10 opacity-20 pointer-events-none rotate-12 scale-110">
             <Shield size={200} className="text-mume-orange" />
          </div>
          <div className="relative z-10 space-y-8">
             <div className="flex items-center justify-between">
                 <div className="flex items-center gap-3">
                    <Activity size={18} className="text-mume-orange animate-pulse" />
                    <span className="text-[12px] font-tech font-bold text-mume-orange uppercase tracking-[0.5em] text-glow">PROTOCOL_ARCHIVE</span>
                 </div>
                 <div className="px-5 py-2 bg-mume-orange/20 border border-mume-orange/40 rounded-full text-[10px] font-mono text-mume-orange font-bold shadow-lg shadow-orange-950/30">
                    VER: {APP_VERSION}
                 </div>
             </div>
             <div>
                <h2 className="text-4xl sm:text-5xl font-tech font-bold text-white uppercase tracking-tight leading-tight text-glow-premium">Antipiracy Destroyer</h2>
                <p className="text-[12px] font-mono text-zinc-300 uppercase tracking-widest mt-4 italic font-bold">Signal Sovereignty Documentation by {CREATOR_NAME}.</p>
             </div>
          </div>
       </div>

       <div className="space-y-4">
           {/* Section 01: The Destroyer Logic */}
           <AccordionItem title="01. THE DESTRUCTION ARCHITECTURE" defaultOpen={true}>
                <div className="space-y-8">
                    <p className="text-[13px] text-zinc-100 font-mono font-bold leading-relaxed uppercase tracking-wide">
                        How the APD 2.0 God Mode neutralizes corporate tracking and antipiracy anchors:
                    </p>
                    
                    <div className="space-y-4">
                        <div className="p-6 bg-white/[0.04] border border-white/10 rounded-3xl space-y-6 shadow-inner">
                            <div className="flex items-start gap-5">
                                <div className="w-12 h-12 rounded-2xl bg-mume-orange/10 flex items-center justify-center shrink-0 border border-mume-orange/20"><ShieldCheck size={24} className="text-mume-orange" /></div>
                                <div>
                                    <h4 className="text-[14px] font-tech font-bold text-white uppercase tracking-widest mb-2">Phase I: Header Decoupling</h4>
                                    <p className="text-[11px] font-mono text-zinc-400 uppercase leading-relaxed font-bold"> Corporate files are tethered to ID3/Vorbis/MP4 metadata containers. The Destroyer separates the raw PCM binary from these containers, effectively stripping the corporate identity from the signal before ingestion.</p>
                                </div>
                            </div>
                            
                            <div className="flex items-start gap-5">
                                <div className="w-12 h-12 rounded-2xl bg-red-600/10 flex items-center justify-center shrink-0 border border-red-600/20"><ShieldAlert size={24} className="text-red-500" /></div>
                                <div>
                                    <h4 className="text-[14px] font-tech font-bold text-white uppercase tracking-widest mb-2">Phase II: Anchor Neutralization</h4>
                                    <p className="text-[11px] font-mono text-zinc-400 uppercase leading-relaxed font-bold"> Corporate Antipiracy utilizes "DRM Anchors"—silent ultrasonic frequency markers that track audio. APD scans the waveform for pattern-matched spikes and voids them at the binary level.</p>
                                </div>
                            </div>

                            <div className="flex items-start gap-5">
                                <div className="w-12 h-12 rounded-2xl bg-tech-cyan/10 flex items-center justify-center shrink-0 border border-tech-cyan/20"><Zap size={24} className="text-tech-cyan" /></div>
                                <div>
                                    <h4 className="text-[14px] font-tech font-bold text-white uppercase tracking-widest mb-2">Phase III: Entropy Normalization</h4>
                                    <p className="text-[11px] font-mono text-zinc-400 uppercase leading-relaxed font-bold"> Tracers are hidden in the noise floor of commercial audio. The kernel re-normalizes the entropy of the track, applying a sanitized noise floor that masks sub-perceptual corporate watermarks while maintaining 1:1 audio fidelity.</p>
                                </div>
                            </div>

                            <div className="flex items-start gap-5">
                                <div className="w-12 h-12 rounded-2xl bg-purple-500/10 flex items-center justify-center shrink-0 border border-purple-500/20"><Atom size={24} className="text-purple-400" /></div>
                                <div>
                                    <h4 className="text-[14px] font-tech font-bold text-white uppercase tracking-widest mb-2">Phase IV: Binary Purge</h4>
                                    <p className="text-[11px] font-mono text-zinc-400 uppercase leading-relaxed font-bold"> The final reconstruction is verified against the APD Signature Database. Any remaining corporate residue is purged, ensuring the signal is now a "Clean Manifestation" within the local vault.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
           </AccordionItem>

           {/* Section 02: RESTRICTED ACCESS (EXPORT) */}
           <AccordionItem title="02. SIGNAL LIBERATION: STATUS_LOCKED">
                <div className="space-y-6">
                    <div className="p-8 bg-red-600/10 border border-red-600/40 rounded-[2.5rem] flex items-start gap-6 shadow-inner">
                        <Lock size={36} className="text-red-500 shrink-0 mt-1" />
                        <div className="space-y-5">
                            <h4 className="text-[15px] font-tech font-bold text-white uppercase tracking-widest text-glow">DIRECTIVE_JHONDURD3N::RESTRICTION</h4>
                            <p className="text-[12px] font-mono text-zinc-100 uppercase leading-relaxed font-bold">
                                "The Signal Liberation (Export) module is currently LOCKED."
                            </p>
                            <p className="text-[11px] font-mono text-zinc-400 uppercase leading-relaxed font-bold">
                                Logic: Refinement Required. The current reconstruction kernel is undergoing high-fidelity optimization to handle multi-layered DRM entropy. Until the bridge is 100% stable, the Architect has locked this feature to prevent signal corruption.
                            </p>
                            <div className="flex items-center gap-3 py-2 px-4 bg-black/40 rounded-xl border border-white/5">
                                <Activity size={12} className="text-red-500" />
                                <span className="text-[9px] font-tech font-bold uppercase tracking-widest text-zinc-500">ESTIMATED REFINEMENT: KERNEL_14.9</span>
                            </div>
                        </div>
                    </div>
                </div>
           </AccordionItem>

           {/* Section 03: ANTIPIRACY BENEFITS */}
           <AccordionItem title="03. DESTROYER PROTOCOL BENEFITS">
                <div className="space-y-12">
                    <p className="text-[13px] text-zinc-200 font-mono font-bold leading-relaxed uppercase tracking-wide">
                        Specific advantages of the God-Mode Antipiracy Destruction logic:
                    </p>
                    <div className="space-y-14">
                        {DETAILED_BENEFITS.filter(b => b.category.includes('Destroyer') || b.category.includes('Security')).map((cat, idx) => (
                            <div key={idx} className="space-y-6">
                                <h4 className="text-[13px] font-tech font-bold text-mume-orange uppercase tracking-[0.3em] px-3 flex items-center gap-4 text-glow">
                                    <Target size={18} /> {cat.category}
                                </h4>
                                <div className="grid grid-cols-1 gap-4">
                                    {cat.items.map((item, i) => (
                                        <div key={i} className="flex items-start gap-5 p-6 bg-white/[0.05] border border-white/10 rounded-2xl transition-all hover:bg-white/[0.1] hover:border-mume-orange/20 group shadow-md">
                                            <div className="mt-1.5 w-2.5 h-2.5 rounded-full bg-mume-orange/40 shrink-0 group-hover:bg-mume-orange transition-colors shadow-[0_0_12px_rgba(255,107,0,0.3)]" />
                                            <span className="text-[11px] font-mono text-zinc-200 uppercase leading-snug font-bold group-hover:text-white transition-colors">{item}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
           </AccordionItem>

           {/* Section 04: Architect Identity */}
           <AccordionItem title="04. ARCHITECT VERIFICATION">
                <div className="space-y-6">
                    <p className="text-[13px] text-zinc-200 font-mono font-bold leading-relaxed uppercase text-justify">
                        {APP_DISPLAY_NAME} is an autonomous project by **{CREATOR_NAME}**. It exists outside of standard corporate app store protocols to ensure absolute signal integrity and user sovereignty. 
                    </p>
                    <div className="p-10 bg-purple-500/10 border border-purple-500/40 rounded-[3.5rem] text-center italic shadow-[inset_0_0_50px_rgba(168,85,247,0.1)]">
                        <span className="text-[13px] font-mono text-purple-100 uppercase leading-tight tracking-[0.4em] font-bold text-glow">"CODE IS LAW. THE SIGNAL IS SOVEREIGNTY."</span>
                    </div>
                </div>
           </AccordionItem>
       </div>

       <div className="mt-20 pb-16 text-center space-y-4">
           <div className="h-px w-72 bg-gradient-to-r from-transparent via-zinc-700 to-transparent mx-auto mb-12"></div>
           <p className="text-[15px] font-tech font-bold uppercase tracking-[0.8em] text-zinc-400 text-glow-premium">ENGINEERED BY {CREATOR_NAME}</p>
           <p className="text-[11px] font-mono text-zinc-600 uppercase tracking-[0.5em] font-bold">APD_PROFESSIONAL_GOD_MODE_14.8.1</p>
       </div>
    </div>
  );
};

export default OperationsManual;
