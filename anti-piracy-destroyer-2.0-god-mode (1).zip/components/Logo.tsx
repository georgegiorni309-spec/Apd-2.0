import React from 'react';

export const Logo = ({ className = "", size = 24 }: { className?: string; size?: number }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    style={{ color: '#D4AF37' }} // Default to alchemy gold to prevent invisibility on black background
    aria-label="Subliminal Cartel Logo"
  >
    {/* Outer Triangle */}
    <path 
      d="M50 10 L90 90 H10 L50 10Z" 
      stroke="currentColor" 
      strokeWidth="8" 
      strokeLinejoin="round"
    />
    
    {/* Inner Eye Shape */}
    <path 
      d="M25 60 C25 60 35 45 50 45 C65 45 75 60 75 60 C75 60 65 75 50 75 C35 75 25 60 25 60Z" 
      stroke="currentColor" 
      strokeWidth="5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    
    {/* Pupil */}
    <circle cx="50" cy="60" r="6" fill="currentColor" />
    
    {/* Top Triangle Tip Separation (Stylistic detail from reference) */}
    <path d="M50 10 L50 25" stroke="currentColor" strokeWidth="2" />
  </svg>
);

export default Logo;