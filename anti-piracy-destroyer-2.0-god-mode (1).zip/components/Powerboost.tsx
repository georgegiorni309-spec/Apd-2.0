
import React, { memo } from 'react';
// Fix: Added AnimatePresence to the framer-motion imports as it is used in the component.
import { motion, AnimatePresence } from 'framer-motion';
import { useAudio } from '../context/AudioContext';
import { Atom, Zap } from 'lucide-react';

const Powerboost: React.FC = () => {
  const { isPlaying, nuclearMode } = useAudio();
  const bioEase = [0.445, 0.05, 0.55, 0.95];

  return (
    <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none rounded-full overflow-hidden hardware-accelerated">
      
      {/* Dynamic Halo Glow */}
      <motion.div 
        animate={{ 
          opacity: isPlaying ? [0.1, 0.2, 0.1] : 0.05,
          scale: isPlaying ? [1, 1.15, 1] : 1,
        }}
        transition={{ duration: 6, repeat: Infinity, ease: bioEase }}
        className="absolute w-[80%] h-[80%] blur-[40px] rounded-full"
        style={{ background: nuclearMode ? 'radial-gradient(circle, rgba(239, 68, 68, 0.4) 0%, transparent 70%)' : 'radial-gradient(circle, var(--theme-accent) 0%, transparent 70%)' }}
      />

      {/* Main Signal Core */}
      <motion.div
        animate={{ 
          rotate: isPlaying ? 360 : 0,
          scale: isPlaying ? [1, 1.02, 1] : 1
        }}
        transition={{ 
          rotate: { duration: 40, repeat: Infinity, ease: "linear" },
          scale: { duration: 8, repeat: Infinity, ease: bioEase }
        }}
        className="absolute w-full h-full mix-blend-overlay opacity-20 bg-center bg-no-repeat"
        style={{ 
          backgroundImage: "url('./mandala.png')", 
          backgroundSize: '110%',
          filter: nuclearMode ? 'hue-rotate(-20deg) brightness(1.5)' : 'brightness(1.1)',
        }}
      />

      {/* Central Identity Spark */}
      <div className="relative flex items-center justify-center">
        <motion.div
          animate={{ 
            scale: isPlaying ? [1, 1.2, 1] : 1,
            opacity: isPlaying ? [0.6, 1, 0.6] : 0.5
          }}
          transition={{ duration: 4, repeat: Infinity, ease: bioEase }}
          className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center backdrop-blur-xl shadow-2xl"
        >
            <div className="w-1.5 h-1.5 rounded-full bg-mume-orange shadow-[0_0_10px_var(--theme-accent)]" />
        </motion.div>
        
        {/* Orbital Activity */}
        <AnimatePresence>
          {isPlaying && (
            <motion.div
              initial={{ rotate: 0, opacity: 0 }}
              animate={{ rotate: 360, opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ rotate: { duration: 2, repeat: Infinity, ease: "linear" }, opacity: { duration: 0.5 } }}
              className="absolute w-16 h-16 border border-mume-orange/20 rounded-full border-dashed"
            />
          )}
        </AnimatePresence>
      </div>

      <div className="absolute bottom-10 flex flex-col items-center gap-1 opacity-40">
        <div className="flex items-center gap-2">
           <Zap size={6} className="text-mume-orange animate-pulse" />
           <span className="text-[5px] font-mono text-mume-orange tracking-[0.5em] font-bold uppercase">SIG_VAULT_ACTIVE</span>
        </div>
      </div>
    </div>
  );
};

export default memo(Powerboost);
