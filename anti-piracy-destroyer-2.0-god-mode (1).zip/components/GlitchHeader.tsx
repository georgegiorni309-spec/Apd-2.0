import React from 'react';

interface GlitchHeaderProps {
  text: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  color?: string;
}

const GlitchHeader: React.FC<GlitchHeaderProps> = ({ text, size = 'lg', color = 'text-alchemy-gold' }) => {
  const sizeClasses = {
    sm: 'text-sm',
    md: 'text-xl',
    lg: 'text-3xl',
    xl: 'text-4xl md:text-6xl',
  };

  return (
    <div className={`relative inline-block font-header font-bold tracking-[0.2em] ${sizeClasses[size]} ${color} group cursor-default select-none`}>
      <span className="relative z-10 drop-shadow-lg">{text}</span>
      <span className="absolute top-0 left-0 -z-10 w-full h-full text-blood-crimson opacity-0 group-hover:opacity-50 blur-sm transition-opacity duration-500">
        {text}
      </span>
    </div>
  );
};

export default GlitchHeader;