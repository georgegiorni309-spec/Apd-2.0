
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, ShieldCheck, Terminal } from 'lucide-react';

interface Props {
  onClose: () => void;
}

const PurchaseThankYouModal: React.FC<Props> = ({ onClose }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[150] flex items-center justify-center bg-black/95 backdrop-blur-md p-6"
    >
      <motion.div
        initial={{ scale: 0.95, y: 20, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="w-full max-w-md bg-mume-card border border-alchemy-gold/30 rounded-2xl relative overflow-hidden shadow-[0_0_50px_rgba(212,175,55,0.15)]"
      >
        {/* Decorative Header Line */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-alchemy-gold to-transparent"></div>
        
        {/* Content */}
        <div className="p-8 flex flex-col items-center text-center relative z-10">
            
            <motion.div 
                initial={{ scale: 0, rotate: -45 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="w-20 h-20 bg-alchemy-gold/10 rounded-full flex items-center justify-center mb-6 border border-alchemy-gold/20 shadow-[0_0_30px_rgba(212,175,55,0.2)]"
            >
                <ShieldCheck size={40} className="text-alchemy-gold" strokeWidth={1.5} />
            </motion.div>

            <div className="mb-6 space-y-1">
                <div className="flex items-center justify-center gap-2 text-[10px] font-mono text-alchemy-gold uppercase tracking-widest mb-2">
                    <CheckCircle size={12} />
                    <span>Authentication Successful</span>
                </div>
                <h2 className="text-3xl font-tech font-bold text-white uppercase tracking-wider">
                    License Verified
                </h2>
            </div>
            
            <div className="bg-white/5 rounded-xl p-5 mb-8 border border-white/5">
                <p className="text-sm font-sans text-zinc-300 leading-relaxed">
                    Thanks for picking up a copy of <span className="text-white font-bold">Anti Piracy Destroyer</span>.
                </p>
                <div className="h-px w-full bg-white/10 my-3"></div>
                <p className="text-xs font-mono text-zinc-500 leading-relaxed text-justify">
                    Your support really helps keep this project alive and funds the weird science behind these algorithms. You're fully authorized now, so everything is unlocked. Welcome to the team.
                </p>
            </div>

            <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onClose}
                className="w-full py-4 bg-alchemy-gold text-black font-tech font-bold uppercase tracking-[0.2em] rounded-xl hover:bg-white transition-all shadow-[0_10px_20px_rgba(0,0,0,0.3)] flex items-center justify-center gap-2 group"
            >
                <Terminal size={16} className="group-hover:rotate-12 transition-transform" />
                Launch Interface
            </motion.button>
            
            <div className="mt-4 text-[9px] font-mono text-zinc-600 uppercase tracking-widest">
                Unit ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}
            </div>
        </div>

        {/* Background Texture */}
        <div className="absolute inset-0 opacity-5 pointer-events-none z-0" style={{ backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px)', backgroundSize: '100% 4px' }}></div>
      </motion.div>
    </motion.div>
  );
};

export default PurchaseThankYouModal;
