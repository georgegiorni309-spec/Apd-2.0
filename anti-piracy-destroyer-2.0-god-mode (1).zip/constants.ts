
import { LoreEntry } from './types';

export const CREATOR_NAME = "Jhondurd3n";
export const CONTACT_EMAIL = "jhondur3n@gmail.com";
export const STORE_URL = "https://jhondur3n.systeme.io/a94f6eac";
export const UPDATE_URL = "https://drive.google.com/drive/folders/19-giK_rF--u7FFgaQs0j1y7SodUPteKm";
export const CLOUD_FOLDER_URL = "https://drive.google.com/drive/folders/15ZocH5voxnBLQ2Qz-dfzbWlkgWqVTwX-";

export const TARGET_FOLDER_ID = "15ZocH5voxnBLQ2Qz-dfzbWlkgWqVTwX-";
export const SYNC_GATEWAY = "https://script.google.com/macros/s/AKfycbz_VOID_SYNC_V14_STABLE/exec";

export const APP_VERSION = "14.8.1-PROFESSIONAL";
export const APP_DISPLAY_NAME = "APD 2.0 God Mode";

export const PIRATE_WARNING = "SINGULARITY OMEGA ULTRA 14.8. ARCHITECT: JHONDURD3N. KERNEL_OPTIMIZED.";

export const DETAILED_BENEFITS = [
  {
    category: "The Destroyer Protocol (Antipiracy)",
    items: [
      "Header Stripping: Instant removal of ID3, Vorbis, and MP4 corporate identity tags.",
      "Anchor Deletion: Direct neutralizing of ultrasonic frequency spikes used for DRM tracking.",
      "Subliminal Neutralization: Suppression of watermarked signal patterns and hidden trackers.",
      "Entropy Masking: Re-normalization of noise floors to hide digital fingerprints.",
      "Signal Sovereignty: 1:1 binary reconstruction designed for total user privacy."
    ]
  },
  {
    category: "Security & Sovereignty",
    items: [
      "Vault Encapsulation: Files are isolated in the APD Secure Vault (IndexedDB).",
      "Offline Immunity: Operates without a network carrier to prevent telemetry leaks.",
      "DRM Evasion: Designed to bypass standard software-level antipiracy checks.",
      "Zero-Metadata Footprint: Ensures no residue of corporate tracking is left in cache.",
      "Architect Direct: Direct-to-Jhondurd3n feedback loop for signal stability."
    ]
  },
  {
    category: "Interface & Control",
    items: [
      "High-Luminescence View: Enhanced typography for maximum technical legibility.",
      "Motif Matrix: Interface themes optimized for obsidian and cobalt environments.",
      "Protocol Lock: Critical features locked for architectural refinement.",
      "Hardware Sync: GPU-accelerated visualizers and Bluetooth session synchronization.",
      "Nuclear Overdrive: Maximized signal throughput for professional audio environments."
    ]
  }
];

export const LORE_ENTRIES: LoreEntry[] = [
  {
    title: "THE PROFESSIONAL KERNEL",
    content: "Inspired by the architectural precision of Professional Android development, this app utilizes native-tier lifecycle management and IndexedDB vaulting to ensure your manifestation signals never degrade, even in the heart of the void.",
    hazardLevel: 'LOW'
  }
];

export const SYSTEM_LOGS = [
  "BOOTING_PROFESSIONAL_ULTRA_V14.8.1...",
  "ARCHITECT_IDENTIFIED::JHONDURD3N",
  "SIGNAL_DESTROYER_PROTOCOL::INITIALIZING",
  "DRM_ANCHOR_SCAN::ACTIVE",
  "SIGNAL_LIBERATION_PATH::LOCKED_FOR_REFINEMENT",
  "OFFLINE_VAULT::READY"
];
