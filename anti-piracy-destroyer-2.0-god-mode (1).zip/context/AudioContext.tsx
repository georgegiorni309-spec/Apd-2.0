
import React, { createContext, useContext, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Howl, Howler } from 'howler';
import { AudioFile, AIProtocol, AIScannerState, UploadStatus, RepeatMode, ViewState, QueueItem, AppTheme, BackgroundType } from '../types';
import { SYNC_GATEWAY, TARGET_FOLDER_ID, CREATOR_NAME, APP_DISPLAY_NAME } from '../constants';

const DB_NAME = 'APD_Secure_Vault_V14';
const DB_STORE_PLAYLIST = 'playlist_data';

Howler.autoUnlock = true;
Howler.stopAudioContextOnPageHide = false; 

export type ExportFormat = 'wav' | 'mp3' | 'flac' | 'ogg';
export type PerfTier = 'ULTRA' | 'STABLE' | 'LITE';

export interface Toast { id: string; message: string; type: 'success' | 'error' | 'info'; }
export interface ExportStatus { progress: number; filename: string; isProcessing: boolean; currentAction?: string; }

interface AudioContextType {
  view: ViewState; setView: (v: ViewState) => void;
  playlist: AudioFile[]; currentIndex: number;
  isPlaying: boolean; currentTime: number; duration: number;
  isShuffle: boolean; toggleShuffle: () => void;
  repeatMode: RepeatMode; toggleRepeat: () => void;
  nuclearMode: boolean; toggleNuclearMode: () => void;
  aiState: AIScannerState; exportStatus: ExportStatus | null;
  toasts: Toast[]; removeToast: (id: string) => void;
  addToast: (message: string, type: Toast['type']) => void;
  showTerminal: boolean; setShowTerminal: (v: boolean) => void; 
  showDonation: boolean; setShowDonation: (v: boolean) => void;
  showUpgradeModal: boolean; setShowUpgradeModal: (v: boolean) => void;
  togglePlay: () => void; playTrack: (track: AudioFile) => void;
  nextTrack: () => void; prevTrack: () => void;
  seek: (time: number) => void; processFiles: (files: File[]) => Promise<void>;
  removeTrack: (track: AudioFile) => void; clearPlaylist: () => void;
  analyser: AnalyserNode | null; currentTrack: AudioFile | undefined;
  perfTier: PerfTier; isVisible: boolean;
  runMetadataAnalysis: () => Promise<void>;
  exportTrack: (track: AudioFile) => Promise<void>;
  cancelExport: () => void; theme: AppTheme; setTheme: (t: AppTheme) => void;
  bgType: BackgroundType; setBgType: (b: BackgroundType) => void;
  fileQueue: QueueItem[]; clearCompletedQueue: () => void; isOnline: boolean;
  isProcessing: boolean; processingProgress: number;
}

const AudioContext = createContext<AudioContextType | null>(null);
export const useAudio = () => {
  const context = useContext(AudioContext);
  if (!context) throw new Error('useAudio must be used within an AudioProvider');
  return context;
};

const getCodecHint = (filename: string): string => {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  const map: Record<string, string> = { 'm4a': 'm4a', 'mp3': 'mp3', 'wav': 'wav', 'flac': 'flac', 'ogg': 'ogg' };
  return map[ext] || ext;
};

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [view, setView] = useState<ViewState>(() => (localStorage.getItem('apd_last_view') as ViewState) || 'library');
  const [showTerminal, setShowTerminal] = useState(false); 
  const [showDonation, setShowDonation] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [playlist, setPlaylist] = useState<AudioFile[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isShuffle, setIsShuffle] = useState(() => localStorage.getItem('apd_shuffle') === 'true');
  const [repeatMode, setRepeatMode] = useState<RepeatMode>(() => (localStorage.getItem('apd_repeat') as RepeatMode) || 'all');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [nuclearMode, setNuclearMode] = useState(() => localStorage.getItem('apd_nuclear') === 'true');
  const [perfTier, setPerfTier] = useState<PerfTier>('STABLE');
  const [exportStatus, setExportStatus] = useState<ExportStatus | null>(null);
  const [theme, setTheme] = useState<AppTheme>(() => (localStorage.getItem('apd_theme') as AppTheme) || 'obsidian');
  const [bgType, setBgType] = useState<BackgroundType>(() => (localStorage.getItem('apd_bg_type') as BackgroundType) || 'full');
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isVisible, setIsVisible] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);

  const soundRef = useRef<Howl | null>(null);
  const currentActiveUrlRef = useRef<string | null>(null);
  const playlistRef = useRef<AudioFile[]>([]);
  const shuffleStackRef = useRef<number[]>([]); 
  const analyserRef = useRef<AnalyserNode | null>(null);
  const dbRef = useRef<IDBDatabase | null>(null);

  useEffect(() => {
    const online = () => setIsOnline(true);
    const offline = () => setIsOnline(false);
    window.addEventListener('online', online);
    window.addEventListener('offline', offline);
    return () => {
      window.removeEventListener('online', online);
      window.removeEventListener('offline', offline);
    };
  }, []);

  const updateMediaSession = useCallback((track: AudioFile) => {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.name,
        artist: CREATOR_NAME,
        album: APP_DISPLAY_NAME,
        artwork: [{ src: './logo.svg', sizes: '512x512', type: 'image/svg+xml' }]
      });
      navigator.mediaSession.setActionHandler('play', () => soundRef.current?.play());
      navigator.mediaSession.setActionHandler('pause', () => soundRef.current?.pause());
      navigator.mediaSession.setActionHandler('previoustrack', () => prevTrack());
      navigator.mediaSession.setActionHandler('nexttrack', () => nextTrack());
    }
  }, []);

  useEffect(() => {
    const handleVisibility = () => setIsVisible(!document.hidden);
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, []);

  const cleanupActiveSignal = useCallback(() => {
    if (soundRef.current) {
        soundRef.current.stop();
        soundRef.current.unload();
        soundRef.current = null;
    }
    if (currentActiveUrlRef.current) {
        URL.revokeObjectURL(currentActiveUrlRef.current);
        currentActiveUrlRef.current = null;
    }
  }, []);

  const openDB = useCallback((): Promise<IDBDatabase> => {
    if (dbRef.current) return Promise.resolve(dbRef.current);
    return new Promise((res, rej) => {
      const req = indexedDB.open(DB_NAME, 14);
      req.onsuccess = () => { dbRef.current = req.result; res(req.result); };
      req.onerror = () => rej(req.error);
      req.onupgradeneeded = (e) => {
        const db = (e.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(DB_STORE_PLAYLIST)) db.createObjectStore(DB_STORE_PLAYLIST, { keyPath: "id", autoIncrement: true });
      };
    });
  }, []);

  useEffect(() => {
    const load = async () => {
      try {
        const db = await openDB();
        const tx = db.transaction([DB_STORE_PLAYLIST], "readonly");
        const store = tx.objectStore(DB_STORE_PLAYLIST);
        const allReq = store.getAll();
        allReq.onsuccess = () => {
          const results = allReq.result || [];
          setPlaylist(results.map(f => ({ 
            ...f, 
            dbId: f.id, 
            format: getCodecHint(f.name) 
          })));
        };
      } catch(e) {
        console.error("KERNEL_IDB_FAULT:", e);
      }
    };
    load();
    return () => cleanupActiveSignal();
  }, [openDB, cleanupActiveSignal]);

  useEffect(() => { playlistRef.current = playlist; }, [playlist]);

  const generateShuffleStack = useCallback((length: number, excludeIdx?: number) => {
    let indices = Array.from({ length }, (_, i) => i);
    for (let i = indices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [indices[i], indices[j]] = [indices[j], indices[i]];
    }
    if (excludeIdx !== undefined && indices.length > 1) {
        return indices.filter(i => i !== excludeIdx);
    }
    return indices;
  }, []);

  const playTrackById = useCallback((dbId: number) => {
    const track = playlistRef.current.find(t => t.dbId === dbId);
    if (!track || !track.file) return;
    
    cleanupActiveSignal();
    const url = URL.createObjectURL(track.file);
    currentActiveUrlRef.current = url;

    const sound = new Howl({
      src: [url], 
      format: [track.format || 'mp3'],
      html5: true, 
      preload: true,
      onplay: () => {
        setIsPlaying(true); 
        setDuration(sound.duration());
        updateMediaSession(track);
        if (!analyserRef.current && Howler.ctx) {
          analyserRef.current = Howler.ctx.createAnalyser(); 
          analyserRef.current.fftSize = 64; 
          Howler.masterGain.connect(analyserRef.current);
        }
      },
      onpause: () => setIsPlaying(false),
      onstop: () => setIsPlaying(false),
      onend: () => {
        if (repeatMode === 'one') {
          playTrackById(dbId);
        } else {
          nextTrack();
        }
      },
      onloaderror: () => {
        window.dispatchEvent(new CustomEvent('apd-system-log', { detail: `KERNEL_SIGNAL_DECODE_ERR: ${track.name}` }));
      }
    });
    
    soundRef.current = sound;
    setCurrentIndex(playlistRef.current.indexOf(track));
    sound.play();
  }, [cleanupActiveSignal, repeatMode, updateMediaSession]);

  const nextTrack = useCallback(() => {
    const list = playlistRef.current; if (!list.length) return;
    let nextIdx = 0;
    if (isShuffle) {
        if (shuffleStackRef.current.length === 0) shuffleStackRef.current = generateShuffleStack(list.length, currentIndex);
        nextIdx = shuffleStackRef.current.pop()!;
    } else {
        nextIdx = (currentIndex + 1) % list.length;
        if (nextIdx === 0 && repeatMode === 'off') { setIsPlaying(false); return; }
    }
    playTrackById(list[nextIdx].dbId!);
  }, [currentIndex, isShuffle, repeatMode, generateShuffleStack, playTrackById]);

  const prevTrack = useCallback(() => {
    const list = playlistRef.current; if (!list.length) return;
    const prevIdx = (currentIndex - 1 + list.length) % list.length;
    playTrackById(list[prevIdx].dbId!);
  }, [currentIndex, playTrackById]);

  const addToast = useCallback((m: string, t: Toast['type']) => { 
    const id = Math.random().toString(); 
    setToasts(p => [...p, {id, message: m, type: t}]); 
    setTimeout(() => setToasts(p => p.filter(x => x.id !== id)), 4000); 
  }, []);

  const value = useMemo(() => ({
    view, setView: (v: ViewState) => { setView(v); localStorage.setItem('apd_last_view', v); },
    playlist, currentIndex, isPlaying, currentTime, duration,
    isShuffle, toggleShuffle: () => { 
        const next = !isShuffle;
        setIsShuffle(next); 
        localStorage.setItem('apd_shuffle', String(next));
        shuffleStackRef.current = []; 
    }, 
    repeatMode, toggleRepeat: () => {
        const modes: RepeatMode[] = ['off', 'all', 'one'];
        const next = modes[(modes.indexOf(repeatMode) + 1) % modes.length];
        setRepeatMode(next);
        localStorage.setItem('apd_repeat', next);
    },
    nuclearMode, toggleNuclearMode: () => {
        const next = !nuclearMode;
        setNuclearMode(next);
        localStorage.setItem('apd_nuclear', String(next));
    },
    aiState: { online: isOnline, analyzing: false, protocol: AIProtocol.IDLE, confidence: 100, threatLevel: 0, signature: "KERNEL_OK", isHostile: false },
    exportStatus, toasts, removeToast: (id: string) => setToasts(t => t.filter(x => x.id !== id)), 
    addToast,
    showTerminal, setShowTerminal, showDonation, setShowDonation, showUpgradeModal, setShowUpgradeModal,
    togglePlay: () => { 
        if (!soundRef.current) { 
            if (playlistRef.current[currentIndex]) playTrackById(playlistRef.current[currentIndex].dbId!); 
            return; 
        } 
        soundRef.current.playing() ? soundRef.current.pause() : soundRef.current.play(); 
    },
    playTrack: (t: AudioFile) => playTrackById(t.dbId!), nextTrack, prevTrack, seek: (t: number) => soundRef.current?.seek(t),
    processFiles: async (files: File[]) => {
      setIsProcessing(true);
      setProcessingProgress(0);
      const db = await openDB();
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        try {
          const tx = db.transaction([DB_STORE_PLAYLIST], "readwrite");
          const store = tx.objectStore(DB_STORE_PLAYLIST);
          await new Promise<void>((resolve, reject) => {
            const req = store.add({ name: f.name, type: f.type, file: f });
            req.onsuccess = () => {
              setPlaylist(p => [...p, { name: f.name, type: f.type, dbId: req.result as number, format: getCodecHint(f.name), file: f }]);
              resolve();
            };
            req.onerror = () => reject(req.error);
          });
          setProcessingProgress(Math.round(((i + 1) / files.length) * 100));
        } catch (err) { console.error("INGESTION_FAULT", err); }
      }
      setIsProcessing(false);
      window.dispatchEvent(new CustomEvent('apd-system-log', { detail: `INGESTION_SUCCESS: ${files.length} NODES` }));
    },
    removeTrack: (t: AudioFile) => { 
      if (t.dbId) { 
        openDB().then(db => {
          const tx = db.transaction([DB_STORE_PLAYLIST], "readwrite");
          tx.objectStore(DB_STORE_PLAYLIST).delete(t.dbId!);
          tx.oncomplete = () => setPlaylist(p => p.filter(x => x.dbId !== t.dbId));
        }); 
      } 
    },
    clearPlaylist: () => { 
        openDB().then(db => {
            const tx = db.transaction([DB_STORE_PLAYLIST], "readwrite");
            tx.objectStore(DB_STORE_PLAYLIST).clear();
            tx.oncomplete = () => { cleanupActiveSignal(); setPlaylist([]); };
        });
        window.dispatchEvent(new CustomEvent('apd-system-log', { detail: `VAULT_VOIDED_BY_USER` }));
    },
    analyser: analyserRef.current, currentTrack: playlist[currentIndex],
    perfTier, isVisible,
    runMetadataAnalysis: async () => {}, 
    exportTrack: async (track: AudioFile) => {
        // Locked as per request
        addToast("PROTOCOL_LOCKED: Liberation tool needs refinement by Architect.", "error");
        window.dispatchEvent(new CustomEvent('apd-system-log', { detail: `EXPORT_ATTEMPT_DENIED: REFINEMENT_REQUIRED` }));
    }, 
    cancelExport: () => setExportStatus(null), 
    theme, setTheme: (t: AppTheme) => { setTheme(t); localStorage.setItem('apd_theme', t); }, 
    bgType, setBgType: (b: BackgroundType) => { setBgType(b); localStorage.setItem('apd_bg_type', b); }, 
    fileQueue: [], clearCompletedQueue: () => {}, isOnline,
    isProcessing, processingProgress
  }), [view, playlist, currentIndex, isPlaying, currentTime, duration, isShuffle, repeatMode, nuclearMode, exportStatus, toasts, showTerminal, showDonation, showUpgradeModal, theme, bgType, isOnline, playTrackById, nextTrack, prevTrack, openDB, cleanupActiveSignal, perfTier, isVisible, isProcessing, processingProgress, addToast]);

  useEffect(() => {
    let rafId: number;
    const syncTime = () => { 
        if (soundRef.current && isPlaying && isVisible) setCurrentTime(soundRef.current.seek() as number); 
        rafId = requestAnimationFrame(syncTime); 
    };
    rafId = requestAnimationFrame(syncTime);
    return () => cancelAnimationFrame(rafId);
  }, [isPlaying, isVisible]);

  return <AudioContext.Provider value={value}>{children}</AudioContext.Provider>;
};
